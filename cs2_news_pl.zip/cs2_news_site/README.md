# CS2 News PL

Gotowa statyczna strona o Counter-Strike 2.

## Co działa
- sekcja aktualnych newsów z modalem i linkiem do źródła,
- ranking światowy i Polska,
- historia Majorów 2013–2026,
- historia Counter-Strike 2010 → 2026,
- wyszukiwarka Majorów,
- filtr po roku,
- countdown do PGL Major Singapore 2026,
- przełącznik jasny/ciemny,
- responsywny wygląd na telefonie i komputerze.

## Publikacja
Strona jest bez frameworków i bez backendu. Wystarczy opublikować `index.html` jako stronę statyczną, np. przez GitHub Pages, Netlify albo inny hosting statyczny.

## Dane
Snapshot danych: 29.09.2026. Źródła są podane bezpośrednio w stopce strony.
